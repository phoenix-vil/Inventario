# Inventario — servidor personal

## Archivos del proyecto

```
inventario/
├── main.py          # API FastAPI (todos los endpoints)
├── database.py      # Modelos SQLite
├── schemas.py       # Validación Pydantic
├── install.sh       # Instalador automático
└── static/
    └── index.html   # App web (se abre en el navegador)
```

## Instalación rápida

```bash
chmod +x install.sh
./install.sh
```

## Uso manual (sin systemd)

```bash
pip install fastapi uvicorn sqlalchemy pydantic --break-system-packages
uvicorn main:app --host 0.0.0.0 --port 8000
```

## Acceso desde tus dispositivos

Desde cualquier dispositivo con Tailscale conectado:

```
http://<ip-tailscale-de-tu-servidor>:8000
```

La IP Tailscale de tu servidor la ves con:
```bash
tailscale ip -4
```

## Endpoints de la API

| Método | Ruta                         | Descripción              |
|--------|------------------------------|--------------------------|
| GET    | /api/productos               | Listar (con filtros)     |
| POST   | /api/productos               | Crear producto           |
| PATCH  | /api/productos/{id}          | Editar producto          |
| DELETE | /api/productos/{id}          | Eliminar                 |
| POST   | /api/productos/{id}/stock    | Ajustar stock (+/-)      |
| GET    | /api/precio/{nombre}         | Consulta rápida de precio|
| GET    | /api/resumen                 | Estadísticas del negocio |
| GET    | /api/categorias              | Lista de categorías      |
| GET    | /docs                        | Documentación interactiva|

## Escáner de código de barras (cámara)

Se agregó un botón **📷 Escanear** que usa la cámara del dispositivo para leer códigos de barras (EAN-13, UPC, Code128, QR, etc.) usando la librería `html5-qrcode`.

**IMPORTANTE:** los navegadores solo permiten acceso a la cámara en **HTTPS** o `localhost`. Como accedes vía `http://<ip-tailscale>:8000`, necesitas activar HTTPS con Tailscale Serve:

```bash
# En el servidor, expón la app con HTTPS automático de Tailscale
sudo tailscale serve https / http://localhost:8000
```

Esto te da una URL tipo `https://tu-equipo.tu-tailnet.ts.net` con certificado válido — ahí la cámara funcionará en todos tus dispositivos.

Verifica con:
```bash
tailscale serve status
```

### Cómo se usa
- **Escanear (barra superior)**: busca un producto existente por su código. Si no existe, te ofrece crearlo con el código ya cargado.
- **Botón 📷 dentro del formulario**: captura el código directo al campo "Código de barras" al crear/editar un producto.

## Inicio de sesión

La app ahora exige iniciar sesión. Al entrar a cualquier página se redirige a /login.

Usuario inicial (gerente): admin / admin123 — cámbialo desde la sección Usuarios.

Roles:
- gerente: acceso total, incluye administrar usuarios y autorizar descuentos
- cajero: usa el punto de venta; no administra usuarios ni autoriza descuentos

La sección Usuarios (visible solo para gerentes en el menú) permite crear usuarios, cambiar contraseñas y eliminar operadores. No se puede borrar el último gerente ni tu propio usuario.

Cada venta queda registrada con el operador que la realizó (aparece en el historial y en el CSV).

### Migración (login y operador en ventas)
Las tablas de sesiones se crean solas al reiniciar. Falta agregar la columna operador a las ventas existentes:

```bash
sqlite3 ~/inventario/inventario.db "ALTER TABLE ventas ADD COLUMN operador TEXT;"
sudo systemctl restart inventario
```

## Punto de venta (Pagos)

La sección `/pagos` es un punto de venta:
- Busca productos por nombre o escanea su código de barras
- Agrega al carrito; los productos por peso piden la cantidad en kg
- Ajusta cantidades con +/− y ve el total en tiempo real
- Descuento extra: requiere autorización de un usuario con rol "gerente" (usuario + contraseña)
- Cobrar: registra la venta y descuenta el stock automáticamente; opcionalmente calcula el cambio

### Usuario por defecto
Al iniciar por primera vez se crea un gerente:
- Usuario: admin
- Contraseña: admin123

Cambia esta contraseña cuanto antes. Desde el botón 👤 (arriba a la derecha en Pagos) puedes crear más usuarios (cajero o gerente). Las contraseñas se guardan con hash PBKDF2-SHA256.

### Migración (tablas de usuarios y ventas)
Las tablas nuevas se crean solas al reiniciar el servicio. Solo reinicia:

```bash
sudo systemctl restart inventario
```

## Migración: venta por peso

Si tu base de datos ya existía, agrega la columna para productos vendidos por peso:

```bash
sqlite3 ~/inventario/inventario.db "ALTER TABLE productos ADD COLUMN vendido_por_peso INTEGER DEFAULT 0;"
sudo systemctl restart inventario
```

Nota: el campo `stock` ahora acepta decimales (ej. 2.5 kg). SQLite lo maneja sin migración adicional. Para productos por peso, el precio se interpreta como precio por kg, y la consulta de precios muestra también el precio por gramo.

## Migración de base de datos (descuentos)

Si tu base de datos ya existía antes de este cambio, agrega las nuevas columnas:

```bash
sqlite3 ~/inventario/inventario.db "ALTER TABLE productos ADD COLUMN descuento_pct REAL DEFAULT 0;"
sqlite3 ~/inventario/inventario.db "ALTER TABLE productos ADD COLUMN descuento_desde TIMESTAMP;"
sqlite3 ~/inventario/inventario.db "ALTER TABLE productos ADD COLUMN descuento_hasta TIMESTAMP;"
sudo systemctl restart inventario
```

## Migración: pago con tarjeta (TPV) y filtros de historial

Agrega las columnas nuevas en ventas para método de pago y datos de la terminal:

```bash
sqlite3 ~/inventario/inventario.db "ALTER TABLE ventas ADD COLUMN metodo_pago TEXT DEFAULT 'efectivo';"
sqlite3 ~/inventario/inventario.db "ALTER TABLE ventas ADD COLUMN tpv_referencia TEXT;"
sqlite3 ~/inventario/inventario.db "ALTER TABLE ventas ADD COLUMN tpv_autorizacion TEXT;"
sqlite3 ~/inventario/inventario.db "ALTER TABLE ventas ADD COLUMN tpv_terminal TEXT;"
sudo systemctl restart inventario
```

En el punto de venta, al cobrar puedes elegir Efectivo o Tarjeta:
- Efectivo: pide "paga con" y calcula el cambio
- Tarjeta: pide los datos del ticket de la TPV (terminal, referencia y código de autorización); no calcula cambio

El historial permite filtrar por rango de fechas, operador y método de pago, con totales separados de efectivo/tarjeta y desglose por operador. El CSV exporta un renglón por producto vendido con número de item, descripción, cantidad, precio e importe, más los datos de pago.

## Migración: número de sucursal

Agrega la columna de sucursal a sesiones y ventas:

```bash
sqlite3 ~/inventario/inventario.db "ALTER TABLE sesiones ADD COLUMN sucursal TEXT;"
sqlite3 ~/inventario/inventario.db "ALTER TABLE ventas ADD COLUMN sucursal TEXT;"
sudo systemctl restart inventario
```

Ahora el login pide el número de sucursal junto a usuario y contraseña. Ese número se guarda con cada venta y aparece en el ticket, el historial y el CSV.

## Comandos útiles

```bash
# Ver si el servicio está corriendo
systemctl status inventario

# Ver logs en tiempo real
journalctl -u inventario -f

# Reiniciar
sudo systemctl restart inventario

# Hacer backup de la base de datos
cp ~/inventario/inventario.db ~/inventario_backup_$(date +%Y%m%d).db
```
