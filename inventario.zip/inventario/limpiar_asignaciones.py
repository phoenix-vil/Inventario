#!/usr/bin/env python3
"""
Elimina TODAS las asignaciones de stock por sucursal (limpia la tabla stock_sucursal).
Útil para resetear después de una prueba.
Uso: python3 limpiar_asignaciones.py [ruta_db]
"""
import sqlite3, sys

DB = sys.argv[1] if len(sys.argv) > 1 else "inventario.db"

conn = sqlite3.connect(DB)
cur = conn.cursor()

cur.execute("SELECT COUNT(*) FROM stock_sucursal")
total = cur.fetchone()[0]

if total == 0:
    print("No hay asignaciones que limpiar.")
    conn.close(); sys.exit(0)

confirmar = input(f"¿Eliminar {total} asignaciones de stock? (s/N): ").strip().lower()
if confirmar != 's':
    print("Cancelado.")
    conn.close(); sys.exit(0)

cur.execute("DELETE FROM stock_sucursal")
conn.commit()
conn.close()
print(f"✓ {total} asignaciones eliminadas. El inventario queda sin distribuir.")
